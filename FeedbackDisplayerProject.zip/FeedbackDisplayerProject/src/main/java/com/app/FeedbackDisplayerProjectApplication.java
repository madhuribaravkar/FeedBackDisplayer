package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackDisplayerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackDisplayerProjectApplication.class, args);
		System.out.println("successfully Run...!");
	}

}
